package com.cg.springwithangular.exceptions;

public class CountryNotFoundException extends Exception {

	public CountryNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CountryNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	 
}
